# angular-crud-example-with-mock-services

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-crud-example-with-mock-services)