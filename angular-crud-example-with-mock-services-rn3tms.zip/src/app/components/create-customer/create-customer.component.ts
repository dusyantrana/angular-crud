import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-create-customer',
  templateUrl: './create-customer.component.html',
  styleUrls: ['./create-customer.component.css'],
})
export class CreateCustomerComponent implements OnInit {
  createCustomerForm: FormGroup;
  constructor(private formBuilder: FormBuilder) {
    this.createCustomerForm = formBuilder.group({
      firstName: [''],
      lastName: [''],
      phone: [''],
      id: [0],
    });
  }

  ngOnInit() {}
}
