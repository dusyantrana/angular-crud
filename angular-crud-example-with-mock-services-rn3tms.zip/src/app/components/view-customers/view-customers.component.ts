import { Component, OnInit } from '@angular/core';
import { Customer } from 'model/customer';
import { Router } from '@angular/router';
import { GetCustomersService } from './../../services/get-customers.service';
@Component({
  selector: 'app-view-customers',
  templateUrl: './view-customers.component.html',
  styleUrls: ['./view-customers.component.css'],
})
export class ViewCustomersComponent implements OnInit {
  customerList: Customer[] = [];
  constructor(
    private router: Router,
    private getAllCustomers: GetCustomersService
  ) {}

  ngOnInit() {
    this.getAllCustomers.getAll().subscribe((response) => {
      this.customerList = response['res'];
    });
  }

  viewCustomer(id) {
    this.router.navigate(['/update']);
  }
}
