import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { GetCustomersService } from './../../services/get-customers.service';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css'],
})
export class UpdateCustomerComponent implements OnInit {
  updateCustomerForm: FormGroup;
  customer: any;
  constructor(
    private formBuilder: FormBuilder,
    private getCustomerService: GetCustomersService
  ) {
    this.updateCustomerForm = this.formBuilder.group({
      firstName: [''],
      lastName: [''],
      phone: [''],
      id: [''],
    });
  }

  ngOnInit() {
    const promise = this.getCustomerService.getById('1');
    promise.then(
      (response) => {
        this.updateCustomerForm.controls['id'].setValue(response['id']);
        this.updateCustomerForm.controls['firstName'].setValue(
          response['firstName']
        );
        this.updateCustomerForm.controls['lastName'].setValue(
          response['lastName']
        );
        this.updateCustomerForm.controls['phone'].setValue(response['phone']);
      },
      (error) => {
        console.log('error ' + error);
      }
    );
  }
}
