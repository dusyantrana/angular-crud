import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../model/Customer';

@Injectable({ providedIn: 'root' })
export class GetCustomersService {
  apiUrl =
    'https://my-json-server.typicode.com/voramahavir/contacts-mock-response/contacts';
  constructor(private http: HttpClient) {}

  getAll() {
    return this.http.get<Customer[]>(this.apiUrl);
  }

  getById(id: string) {
    return this.http.get<Customer>(`${this.apiUrl}/${id}`);
  }
}
