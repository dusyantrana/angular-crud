export class Customer {
  public firstName: string;
  public lastName: string;
  public phone: string;
  public id: string;
}
